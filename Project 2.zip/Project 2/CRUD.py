from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps
import json

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self,username,password):
        # Initializing the MongoClient 
        if username and password:
            self.client = MongoClient('mongodb://%s:%s@localhost:52382/AAC' % (username, password))
            self.database = self.client['AAC']
        else:
            self.client = MongoClient('mongodb://localhost:52382/AAC')
            self.database = self.client['AAC']

# Create method to add new entry
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Read method to get info from database 
    def read(self, search):
        if search is not None:
            result = self.database.animals.find(search, {"_id":False})
            return result
        else:
            raise Exception("Nothing to search, because search parameter is empty")
            
# Method to read the whole database             
    def read_all(self, search):
        return self.database.animals.find({},{"_id":False})
        
              
 # Method to update entry in database
    def update(self,old_data,new_data):
        if old_data is not None:
            if old_data:
                updated = self.database.animals.update(old_data,new_data)
                self.database.animals.delete_one(old_data)
            return dumps(self.read(AnimalShelter, updated))
        else:
            raise Exception("Nothing to update, because data parameter is empty")
           
            
# Method to delete entry in database
    def delete(self, remove):
        if remove is not None:
            if remove:
                deleted = self.database.animals.delete_one(remove)
            return deleted #dumps(self.read(deleted))
        else:
            raise Exception("Nothing to delete, because data parameter is empty")